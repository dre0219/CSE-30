#include <iostream>

using namespace std;

struct Node{
	int data;
	Node* left;
	Node* right;

	Node(){
		data = 0;
		left = NULL;
		right = NULL;
	}

	Node(int x){
		data = x;
		left = NULL;
		right = NULL;
	}
};

void traverse(Node* root){
	if (root != NULL){
		traverse(root->left);
		cout << root->data << endl;
		traverse(root->right);
	}
}

bool search(Node* root, int value){
	if (root == NULL){
		return false;
	}
	else{
		if (root->data == value){
			return true;
		}
		else {
			if (value < root->data){
				return search(root->left, value);
			}
			else{
				return search(root->right, value);
			}
		}
	}
}

Node* insert(Node* root, int x){
	if (root == NULL){
		root = new Node(x);
	}
	else {
		if (x < root->data){
			root->left = insert(root->left, x);
		}
		else {
			root->right = insert(root->right, x);
		}
	}
	return root;
}

//Minimum Value in a tree
Node* findMini(Node* root){
	if (root->left == NULL){
		return root;
	}
	else {
		return findMini(root->left);
	}
}

// A function to display the tree graphically
void displayTree(Node* root, int level, int direction){
    // Don't worry about this function, just use it
    if (root != NULL){
        displayTree(root->right, level+1, 1);
        
        for (int i = 0; i < level-1; i++) {
            std::cout << "   ";
        }
        if (level > 0 ){
            if (direction == 1){
                std::cout << " /--";
            }
            else{
                std::cout << " \\--";
            }
        }
        std::cout << root->data;
        std::cout << std::endl;
        level++;
        
        displayTree(root->left, level, -1);
    }
}

// Call the function to display the tree and leave some space afterwards
void drawTree(Node* root){
    if (root == NULL){
        cout << "Empty tree";
    }
    displayTree(root, 0, 0);
    std::cout << std::endl << std::endl;
}


Node* remove(Node* root, Node* node){
//base case
	if(root == NULL){
		return root;

//When the node data is less than the root data move it to the left
	}else if(node->data < root->data){
		root->left = remove(root->left, node);

//When the node data is greater than the root data move it to the right
	}else if(node->data > root->data){
		root->right = remove(root->right, node);
	}else{
	
	//case 1 with no children
	if(root->left == NULL && root ->right == NULL){
		delete root;
		root = NULL;
	}

	//case 2 with 1 child
	else if(root->left == NULL){

		struct Node* temp = root;
		root = root->right;
		delete temp;
	}

	else if(root-> right == NULL){

		struct Node* temp = root;
		root = root->right;
		delete temp;
	}

	//case 3 with 2 children
	else{

		struct Node* temp = findMini(root->right); //Getting the minimum on the greater side
		root->data = temp->data; //replacing root data to go to the right side
		root->right = remove(root->right, temp); //setting children on the right
		}
	}
	return root; 
}


int main(){

	Node* root = NULL;

	root = insert(root, 5);
	root = insert(root, 3);
	root = insert(root, 8);
	root = insert(root, 2);
	root = insert(root, 6);
	root = insert(root, 4);
	root = insert(root, 9);

	cout << "Original tree:" << endl << endl;

	drawTree(root); 

	remove(root, root);

	cout << "Removed the root:" << endl << endl;

	drawTree(root);

	return 0;
}
