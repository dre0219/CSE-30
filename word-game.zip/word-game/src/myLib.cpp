#include <myLib.h>
#include <algorithm>

std::vector<std::string> readWordsFile(std::string filename){
    std::ifstream file(filename);
    std::string str; 

    std::vector<std::string> words;

    while (std::getline(file, str)){
        words.push_back(boost::to_upper_copy(str));
        
    }

    return words;
}

ucm::json checkWord(std::string word){

    ucm::json x;

    x["word"] = word;
    x["valid"] = false;

    std::vector<std::string> dictionary = readWordsFile("misc/english.txt");

    std::cout << dictionary[0] << std::endl; 
    
    for (int i = 0; i < dictionary.size(); i++){
        if(word == dictionary[i]){
            x["valid"]=true;
            break;
        }
    }
    
    return x;
}

 ucm::json getList(){

     srand (time(NULL));
    ucm::json result;

    for (int i = 0; i < 9; i++){
        int r = rand() % 25 + 65;
        result.push_back(r);
    }
     return result;
 
 }
std::vector<std::string> powerset(std::string str){
    if (str.size() == 0){
        std::vector<std::string> result;
        result.push_back("");

        return result;
    }
    else{
        char head = str[0];
        std::string tail;
        tail = str.substr (1,std::string::npos);

        std::vector<std::string> res = powerset(tail);
        std::vector<std::string> ans = res;

        for (auto element : res){
            std::string temp = element;
            temp.insert(temp.begin(), head);
            ans.push_back(temp);
        }

        return ans;
    }
}

void permute(std::string a, int l, int r, std::vector<std::string>& results) {

    if (l == r)  {
        results.push_back(a);
    }  
    else {  
        for (int i = l; i <= r; i++) {   
            char temp = a[l];
            a[l] = a[i];
            a[i] = temp;
             
            permute(a, l+1, r, results);  

            temp = a[l];
            a[l] = a[i];
            a[i] = temp;  
        }  
    }  
}  


