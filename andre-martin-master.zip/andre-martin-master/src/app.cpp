#include <myLib.h>

int main(int argc, char** argv){

    // Take a look at the 8 tasks below

    // 1. Create an empty IntegerArray and fill it up with 1 million random integers. How long did it take? Answer in milliseconds.

    // 2. Now create an empty LinkedList and fill it up with 1 million random integers. How long did it take? Answer in milliseconds.

    // 3. Now take your IntegerArray and append 1000 random numbers to it. How long did it take?

    // 4. Append 1000 random integers to your Linked List. How long did it take?

    // 5. Is ther a substantial difference between the amount of time it took to append 1000 integers to the array vs the linked list? If there is a difference, explain why it exists. If there is no difference, explain why that't the case.

    // 6. Now take your IntegerArray and prepend (insert at the beginning) 1000 random integers to it. How long did that take?

    // 7. Now prepend 1000 random integers to your Linked List. How long did it take?

    // 8. Is there a difference between the amount of time it takes to prepend to the array vs the linked list, for 1000 integers. If there is a difference, explain why you think it exists. If there is no significant difference, explain why that is.

    // Write all the code necessary to answer the questions

    // Write your answers in the README file


}
