#include <iostream>

#include <TimeSupport.h>

// Solution
// 1. We should utilize the heap for storage using "new" keyword

// 2. We need to create an object, which has a pointer to some storage, but also stores other useful information, such as the size of the array

// 3. We will also implement some functions to read and manipulate the storage, and that will allow us to handle things like out-of-bounds errors.

// Implementation
struct IntegerArray{
	int* storage;
	int size;

	// Constructor
	IntegerArray(){
		size = 10;
		storage = new int[size];
		for (int i = 0; i < size; i++){
			storage[i] = 0;
		}
	}

	IntegerArray(int s){
		size = s;
		storage = new int[size];
		for (int i = 0; i < size; i++){
			storage[i] = 0;
		}
	}

	// Destructor
	~IntegerArray(){
		delete[] storage;
	}

	int& operator[](int index){
		if (index < size){
			return storage[index];
		}
		else{
			
			int newsize = size;
			while (index > newsize -1){
				newsize = newsize * 2;
			}

			int* new_storage = new int[newsize];
			
			int* old_storage = storage;

			for (int i = 0; i < size; i++){
				new_storage[i] = storage[i];
			}

			storage = new_storage;

			delete[] old_storage;
			
			size = newsize;

			return storage[index];
		}
	}

};


struct Link{
	int data;
	Link* next;
};


struct LinkedList{
	Link* head;
	Link* back;

	LinkedList(){
		head = NULL;
		back = NULL;
	}

	void append(int x){
		// Check if the list is currently empty
		if (head == NULL){
			// We need to set the head element to be a Link
			// whose data is x
			head = new Link();
			head->data = x;
			head->next = NULL;
			back = head;
		}
		else{
			// The head is not NULL, so we already have some elements in the list

			// Create a new link
			Link* newNode = new Link();
			newNode->data = x;
			newNode->next = NULL;

			// Now find the last element of the existing list
			// Link* temp = head;

			// while (temp->next != NULL){
			// 	temp = temp->next;
			// }

			// At this place in the code, temp is pointing to the last element of the linked list

			// Connect temp to newNode

			back->next = newNode;
			back = back->next;
		}
	}

	void print(){
		Link* temp = head;
		while (temp != NULL){
			std::cout << temp->data << " ";
			temp = temp->next;
		}
		std::cout << std::endl;
	}
};

int main(){

	int N = 10000000;


	LinkedList myList;

	timestamp start = current_time();

	for (int i = 0; i < N; i++){
		myList.append(i);
	}

	timestamp end = current_time();

	long duration = time_diff(start, end);

	std::cout << "Inserted " << N << ", took " << duration << " ms." << std::endl;


	//myList.print();

	return 0;
}
