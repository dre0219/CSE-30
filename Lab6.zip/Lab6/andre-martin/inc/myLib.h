#ifndef MYLIB
#define MYLIB

#include <ostream>

struct IntegerArray{
	int* storage;
	int capacity;
	int size;

	IntegerArray();

	IntegerArray(int s);

	// This is to specify how to copy our array
	IntegerArray(const IntegerArray& other);

	void append(int value);

	void prepend(int value);

	~IntegerArray();

	// This is to be able to compare if two arrays are equal
	bool operator==(const IntegerArray& other) const;

};

// This allows you to print the array with a single cout <<
std::ostream& operator<<(std::ostream& os, const IntegerArray& arr); 

struct Link{
	int data;
	Link* next;
};


struct LinkedList{
	Link* head;
	Link* back;

	LinkedList();

	LinkedList(const LinkedList& other);

	void append(int x);

	void prepend(int x);

	bool operator==(const LinkedList&) const;

	~LinkedList();
};

// This allows you to print the linked list with a single cout <<
std::ostream& operator<<(std::ostream& os, const LinkedList& arr); 

#endif
