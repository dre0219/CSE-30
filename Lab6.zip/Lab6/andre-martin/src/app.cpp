#include <myLib.h>

int main(int argc, char** argv){

    // Take a look at the 8 tasks below

    // 1. Create an empty IntegerArray and fill it up with 1 million random integers. How long did it take? Answer in milliseconds.
    //Took 18ms
    int main(){

        int N = 1000000;
        IntegerArray myarr;

        timestamp start = current_time();
        for (int i = 0; i < N; i++){
            myarr[i] = rand();
        }
        timestamp end = current_time();

        long duration = time_diff(start, end);

        std::cout << "Inserted " << N << ", took " << duration << " ms. " << std::endl;
        return 0;
    }

    // 2. Now create an empty LinkedList and fill it up with 1 million random integers. How long did it take? Answer in milliseconds.
    // Took 44 ms.
    int main(){

    int N = 10000000;

    LinkedList myList;

    timestamp start = current_time();

    for (int i = 0; i < N; i++){
        myList.append(i);
    }

    timestamp end = current_time();

    long duration = time_diff(start, end);

    std::cout << "Inserted " << N << ", took" << duration << "ms. " << std::endl;

    return 0;
    }
    
    // 3. Now take your IntegerArray and append 1000 random numbers to it. How long did it take?

    //took 0 ms.
        int main(){

            int N - 1000000;
            IntegerArray myarr;

        timestamp start = current_time();
        for (int i = 0; i < N; i++){
            myarr[i] = rand();
        }
        timestamp end = current_time();

        int J = N+1000;

        timestamp start = current_time();
        for (int i = 0; i < J; i++){
            myarr[i] = rand();
        }
        timestamp end = current_time();

        long duration = time_diff(start, end);

        std::cout << "Inserted " << N << ", took" << duration << "ms." << std::endl;
        return 0;
        }

    // 4. Append 1000 random integers to your Linked List. How long did it take?

    //Took 0 ms
    int main(){

        int N = 10000000;

    LinkedList myList;

    for (int i = 0; i < N; i++){
        myList.append(i);
    }

    int j = N + 1000;
    timestamp start = current_time();

    for (int i = 0; i < 1000; i++){
        myList.append(i);
    }


    timestamp end = current_time();

    long duration = time_diff(start, end);

    std::cout << "Inserted " << j << ", took " << duration << " ms." << std::endl:

    return 0;
}    

    // 5. Is ther a substantial difference between the amount of time it took to append 1000 integers to the array vs the linked list? If there is a difference, explain why it exists. If there is no difference, explain why that't the case.

    No there is not a substantial difference between the array and the linked list.

    // 6. Now take your IntegerArray and prepend (insert at the beginning) 1000 random integers to it. How long did that take?

    //Took 13000 ms
    struct IntegerArray{
        int* storage;
        int size;
    }

    IntegerArray(){
        size = 10;
        storage = new int[size];
        for (int i = 0; i < size; i++){
            storage[i] = 0;
        }
    }
    void prepend(int x){
        int oldsize = size;
        size = size + 1;
        int* newsize + new int[size];

        if (storage > 0){
            for {int i = 0; i < oldsize; i++}{
                newsize[i] = storage[i-1];
            }
        }
        delete[] storage;
        storage = newsize;
        storage[0] = x;
    }

    // Destructor
    ~IntegerArray(){
        delete[] storage;
    }

    int& opperator[](int index){
        if (index < size){
            return storage[index];
        }
        else{

            int newsize = size;
            while (index > newsize -1){
                newsize = newsize * 2;
            }

            int* new_storage = new int[newsize];

            int* old_storage = storage;

            for (int i = 0; i < size; i++){
                new_storage[i] = storage[i];
            }

            storage = new_storage;

            delete[] old_storage;

            size = newsize;

            return storage[index]; 
        }

        int main(){
            int N = 1000000;

            IntegerArray myarr;

            for (int i = 0; i < N; i++){
                myarr[i] = rand();
            }
            int j = N + 1000;

            for (int i = 0; i < j; i++){
                myarr.prepend(rand());
            }
            return 0;
        }
    }
    // 7. Now prepend 1000 random integers to your Linked List. How long did it take?
    //Took 140 MS in total.
    int main(){
        int N = 1000000;

        LinkedList myList;

        timestamp start = current_time();

        for (int i = 0; i < N; i++){
            myList.append((rand)));
        }

        int J = N+1000;

        for(int i = 0; i < J; i++){
            myList.prepend((rand)));
        }

        timestamp end = current_time();

        long duration = time_diff(start, end);

        std::cout << "Inserted " << N << ", took " << duration << " ms." << std::endl;

        return 0;

        }

    // 8. Is there a difference between the amount of time it takes to prepend to the array vs the linked list, for 1000 integers. If there is a difference, explain why you think it exists. If there is no significant difference, explain why that is.
    
    With an array since the memory is at an assigned memory location it is faster for the array rather than the linked list which is basically diveded in two and the multiple nodes. 

    // Write all the code necessary to answer the questions

    // Write your answers in the README file


}
