#include <myLib.h>
#include <iostream>
#include <ostream>

// The Integer Array Implementation

IntegerArray::IntegerArray(){
   size = 0;
   storage = NULL;
   capacity = true;
}

IntegerArray::IntegerArray(int s){
   size = s;
   storage = new int[size];
   for (int i = 0; i < size; i++){
      storage[i] = 0;
   }
}

IntegerArray::IntegerArray(const IntegerArray& other){
   size = other.size;
   capacity = other.capacity;
   storage = new int[capacity];

   for (int i = 0; i < size; i++){
      storage[i] = other.storage[i];
   }
}

// A function to append a value to the end of the array
// If the array does not have enough capacity, it should double itself, unless its capacity is 0,
// in which case, it should become 1 (because doubling 0 does not get you 1)
void IntegerArray::append(int value){
   // Complete this function
   if (capacity >= size){
      size = size +1;
      if (capacity < size){
         capacity = capacity*2;
      }
      int* newsize = new int[capacity];

      if (storage > 0){
         for(int i = 0; i < capacity; i++){
            newsize[i] = storage[i-1];
         }
      }
      delete[] storage;
      storage = newsize;

      storage[0] = value;
   }
}

// A function to insert a value at the beginning of the array
// If the array does not have enough capacity, it should double itself, unless its capacity is 0,
// in which case, it should become 1 (because doubling 0 does not get you 1)
void IntegerArray::prepend(int value){
   // Complete this function
}

IntegerArray::~IntegerArray(){
   delete[] storage;
}

bool IntegerArray::operator==(const IntegerArray& other) const {
   if (capacity != other.capacity){
      return false;
   }
   if (size != other.size){
      return false;
   }
   for(int i = 0; i < size; i++){
      if (storage[i] != other.storage[i]){
         return false;
      }
   }
   return true;
}


std::ostream& operator<< (std::ostream& os, const IntegerArray& arr){
   if (arr.size == 0){
      os << "NULL";
   }
   else {
      for (int i = 0; i < arr.size; i++){
         if (i == 0){
            os << arr.storage[i];
         }
         else {
            os << ", " << arr.storage[i];
         }
      }
   }
   return os;
}



// The Linked List Implementation

LinkedList::LinkedList(){
   head = NULL;
   back = NULL;
}

LinkedList::LinkedList(const LinkedList& other){
   head = NULL;
   back = NULL;

   Link* temp = other.head;
   while (temp != NULL){
      append(temp->data);
      temp = temp->next;
   }
}

void LinkedList::append(int x){
   if (head == NULL){
      head = new Link();
      head->data = x;
      head->next = NULL;
      back = head;
   }
   else{
      Link* newNode = new Link();
      newNode->data = x;
      newNode->next = NULL;

      back->next = newNode;
      back = back->next;
   }
}

void LinkedList::prepend(int x){
   // Complete this function
   if (head == NULL){
      head = new Link();
      head->data = x;
      head->next = NULL;
   }
   else{
      Link* newNode = new Link();
      newNode->data = x;
      newNode->next = head;

      head = newNode;
   }
}

bool LinkedList::operator==(const LinkedList& other) const {
   Link* t1 = head;
   Link* t2 = other.head;

   if (t1 == NULL && t2 == NULL){
      return true;
   }
   else {
      while(t1 != NULL){
         if (t2 == NULL){
            return false;
         }
         else{
            if (t1->data != t2->data){
               return false;
            }
         }
         t1 = t1->next;
         t2 = t2->next;
      }
      if (t2 != NULL){
         return false;
      }

      return true;
   }
}

std::ostream& operator<<(std::ostream& os, const LinkedList& list){
   Link* temp = list.head;
   while (temp != NULL){
      os << temp->data << " ";
      temp = temp->next;
   }
   return os;
}

LinkedList::~LinkedList(){
   // Complete this function
   head = NULL;
   back = NULL;
}
