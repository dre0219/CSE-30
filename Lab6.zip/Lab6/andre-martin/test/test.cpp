#include <igloo/igloo.h>
#include <myLib.h>

using namespace igloo;

Context(ArrayTests){
	Spec(EqualityOperatorTriviallyTrue){
		IntegerArray one;
		IntegerArray two;
		Assert::That(one == two, IsTrue());
	}

	Spec(EqualityOperatorFalse){
		IntegerArray one;
		IntegerArray two;
		two.size = 1;
		two.storage = new int(5);
		two.capacity = 1;

		Assert::That(one == two, IsFalse());

		std::cout << two << std::endl;
	}

	Spec(EqualityOperatorTrue){
		IntegerArray one;
		one.size = 1;
		one.storage = new int(5);
		one.capacity = 1;
		IntegerArray two;
		two.size = 1;
		two.storage = new int(5);
		two.capacity = 1;

		Assert::That(one == two, IsTrue());
	}

	Spec(AppendFromEmpty){
		IntegerArray one;
		one.append(7);

		IntegerArray two;
		two.capacity = 1;
		two.size = 1;
		two.storage = new int(7);

		Assert::That(one, Equals(two));
	}

	Spec(AppendTwice){
		IntegerArray one;
		one.append(7);
		one.append(5);
		
		IntegerArray two;
		two.capacity = 2;
		two.size = 2;
		two.storage = new int[2];
		two.storage[0] = 7;
		two.storage[1] = 5;

		Assert::That(one, Equals(two));
	}

	Spec(AppendThreeTimes){
		IntegerArray one;
		one.append(7);
		one.append(5);
		one.append(9);
		
		IntegerArray two;
		two.capacity = 4;
		two.size = 3;
		two.storage = new int[4];
		two.storage[0] = 7;
		two.storage[1] = 5;
		two.storage[2] = 9;

		Assert::That(one, Equals(two));
	}

	Spec(PrependFromEmpty){
		IntegerArray one;
		one.prepend(42);

		IntegerArray two;
		two.size = 1;
		two.capacity = 1;
		two.storage = new int(42);

		Assert::That(one, Equals(two));
	}

	Spec(PrependTwice){
		IntegerArray one;
		one.prepend(7);
		one.prepend(5);

		IntegerArray two;
		two.size = 2;
		two.capacity = 2;
		two.storage = new int[2];
		two.storage[0] = 5;
		two.storage[1] = 7;

		Assert::That(one, Equals(two));
	}

	Spec(PrependThreeTimes){
		IntegerArray one;
		one.prepend(9);
		one.prepend(7);
		one.prepend(5);

		IntegerArray two;
		two.size = 3;
		two.capacity = 4;
		two.storage = new int[4];
		two.storage[0] = 5;
		two.storage[1] = 7;
		two.storage[2] = 9;

		Assert::That(one, Equals(two));
	}
};

Context(LinkedListTests){
	Spec(EqualityOperatorTriviallyTrue){
		LinkedList one;
		LinkedList two;

		Assert::That(one == two, IsTrue());
	}

	Spec(EqualityOperatorFalse){
		LinkedList one;
		one.append(5);

		LinkedList two;

		Assert::That(one == two, IsFalse());
	}

	Spec(EqualityOperatorTrue){
		LinkedList one;
		one.append(7);

		LinkedList two;
		two.append(7);

		Assert::That(one == two, IsTrue());
	}

	Spec(AppendFromEmpty){
		LinkedList one;
		one.append(7);

		LinkedList two;
		two.head = new Link;
		two.head->data = 7;
		two.head->next = NULL;
		two.back = two.head;

		Assert::That(one, Equals(two));
	}

	Spec(AppendTwice){
		LinkedList one;
		one.append(7);
		one.append(9);

		LinkedList two;
		two.head = new Link;
		two.head->data = 7;
		
		two.head->next = new Link;
		two.head->next->data = 9;
		two.head->next->next = NULL;
		two.back = two.head->next;

		Assert::That(one, Equals(two));
	}

	Spec(PrependFromEmpty){
		LinkedList one;
		one.prepend(7);

		LinkedList two;
		two.head = new Link;
		two.head->data = 7;
		two.head->next = NULL;
		two.back = two.head;

		Assert::That(one, Equals(two));
	}

	Spec(PrependTwice){
		LinkedList one;
		one.prepend(7);
		one.prepend(5);

		LinkedList two;
		two.head = new Link;
		two.head->data = 5;
		two.head->next = new Link;
		two.head->next->data = 7;
		two.head->next->next = NULL;
		two.back = two.head->next;

		Assert::That(one, Equals(two));
	}
};



int main() {
	// Run all the tests defined above
	return TestRunner::RunAllTests();
}
