#include <myLib.h>
#include <string>
#include <iostream>

std::string sayHello(){
    return "Hello World";
}

std::string echoWord(std::string word){
    std::string result;
    for (int i = word.length() - 1; i >= 0; i--){
        result.push_back(word.at(i));
    }
    return result;
}

ucm::json getSuperBowlScore(){
        ucm::json data;      
        data["home_team"] = "New England Patriots";
        data["home_score"] = 13;
        data["away_team"] = "Los Angeles Rams";
        data["away_score"] = 3;
        
        return data;
}
std::string upperCase(std::string word){
    
    std::string upper, lower;
    for (int i = 0; i < word.length(); i++){
        upper.push_back(toupper(word.at(i)));
        lower.push_back(tolower(word.at(i)));
    }
    
    return ("Uppercase [" + upper + "] : Lowercase [" + lower + "]");
}