#include <iostream>
#include <myLib.h>
#include <unordered_map>


int main(){

	


	return 0;
}
